<?php
/**
 * Plugin Name: Hoteller Theme Elements for Elementor
 * Description: Custom elements for Elementor using Hoteller theme
 * Plugin URI:  https://themegoods.com/
 * Version:     1.9
 * Author:      ThemGoods
 * Author URI:  https://themegoods.com/
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die();
}

define( 'HOTELLER_ELEMENTOR_PATH', plugin_dir_path( __FILE__ ));

if (!defined('HOTELLER_THEMEDATEFORMAT'))
{
	define("HOTELLER_THEMEDATEFORMAT", get_option('date_format'));
}

if (!defined('HOTELLER_THEMETIMEFORMAT'))
{
	define("HOTELLER_THEMETIMEFORMAT", get_option('time_format'));
}

/**
 * Load the plugin after Elementor (and other plugins) are loaded.
 *
 * @since 1.0.0
 */
function hoteller_elementor_load() {
	load_plugin_textdomain( 'hoteller-elementor', FALSE, dirname( plugin_basename(__FILE__) ) . '/languages/' );
	
	// Require the main plugin file
	require(HOTELLER_ELEMENTOR_PATH.'/tools.php');
	require(HOTELLER_ELEMENTOR_PATH.'/actions.php');
	require(HOTELLER_ELEMENTOR_PATH.'/templates.php' );
	require(HOTELLER_ELEMENTOR_PATH.'/plugin.php' );
}
add_action( 'plugins_loaded', 'hoteller_elementor_load' );

//Add featured image support for room attribute
add_post_type_support( 'mphb_room_attribute', 'thumbnail' );
