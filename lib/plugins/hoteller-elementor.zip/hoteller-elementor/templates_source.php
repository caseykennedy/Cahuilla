<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class Hoteller_Templates_Source extends Elementor\TemplateLibrary\Source_Base {

	/**
	 * Template prefix
	 *
	 * @var string
	 */
	protected $template_prefix = 'hoteller_';

	/**
	 * Return JetImpex templates prefix
	 *
	 * @return [type] [description]
	 */
	public function get_prefix() {
		return $this->template_prefix;
	}

	public function get_id() {
		return 'hoteller-templates';
	}

	public function get_title() {
		return __( 'Hoteller Templates', 'hoteller-elementor' );
	}

	public function register_data() {}

	public function get_items( $args = array() ) {
		
		$templates = array();

		$templates_data = array(
			1 	=> array(
				'template_id'      	=> $this->template_prefix .'1',
				'source'            => $this->get_id(),
				'title'             => 'About Us 1',
				'thumbnail'         => 'http://assets.themegoods.com/demo/hoteller/templates/screenshots/hoteller_1.png',
				'date'      		=> date( get_option( 'date_format' ), 1531297160 ),
				'type'				=> 'page',
				'subtype'			=> 'page',
				'author'            => 'ThemeGoods',
				'categories'        => array(),
				'keywords'          => array('about'),
				'is_pro'            => false,
				'has_page_settings' => false,
				'url'               => 'https://themes.themegoods.com/hoteller/luxury/about-us/',
			),
			2 	=> array(
				'template_id'      	=> $this->template_prefix .'2',
				'source'            => $this->get_id(),
				'title'             => 'Our Rooms 1',
				'thumbnail'         => 'http://assets.themegoods.com/demo/hoteller/templates/screenshots/hoteller_2.png',
				'date'      		=> date( get_option( 'date_format' ), 1531297160 ),
				'type'				=> 'page',
				'subtype'			=> 'page',
				'author'            => 'ThemeGoods',
				'categories'        => array(),
				'keywords'          => array('our rooms'),
				'is_pro'            => false,
				'has_page_settings' => false,
				'url'               => 'https://themes.themegoods.com/hoteller/luxury/our-rooms/',
			),
			3 	=> array(
				'template_id'      	=> $this->template_prefix .'3',
				'source'            => $this->get_id(),
				'title'             => 'Contact',
				'thumbnail'         => 'http://assets.themegoods.com/demo/hoteller/templates/screenshots/hoteller_3.png',
				'date'      		=> date( get_option( 'date_format' ), 1531297160 ),
				'type'				=> 'page',
				'subtype'			=> 'page',
				'author'            => 'ThemeGoods',
				'categories'        => array(),
				'keywords'          => array('contact'),
				'is_pro'            => false,
				'has_page_settings' => false,
				'url'               => 'https://themes.themegoods.com/hoteller/luxury/contact/',
			),
			4 	=> array(
				'template_id'      	=> $this->template_prefix .'4',
				'source'            => $this->get_id(),
				'title'             => 'Offer & Package',
				'thumbnail'         => 'http://assets.themegoods.com/demo/hoteller/templates/screenshots/hoteller_4.png',
				'date'      		=> date( get_option( 'date_format' ), 1531297160 ),
				'type'				=> 'page',
				'subtype'			=> 'page',
				'author'            => 'ThemeGoods',
				'categories'        => array(),
				'keywords'          => array('offer'),
				'is_pro'            => false,
				'has_page_settings' => false,
				'url'               => 'https://themes.themegoods.com/hoteller/luxury/offer-package/',
			),
			5 	=> array(
				'template_id'      	=> $this->template_prefix .'5',
				'source'            => $this->get_id(),
				'title'             => 'Testimonial',
				'thumbnail'         => 'http://assets.themegoods.com/demo/hoteller/templates/screenshots/hoteller_5.png',
				'date'      		=> date( get_option( 'date_format' ), 1531297160 ),
				'type'				=> 'page',
				'subtype'			=> 'page',
				'author'            => 'ThemeGoods',
				'categories'        => array(),
				'keywords'          => array('testimonial'),
				'is_pro'            => false,
				'has_page_settings' => false,
				'url'               => 'https://themes.themegoods.com/hoteller/luxury/testimonial/',
			),
			6 	=> array(
				'template_id'      	=> $this->template_prefix .'6',
				'source'            => $this->get_id(),
				'title'             => 'Our Menus',
				'thumbnail'         => 'http://assets.themegoods.com/demo/hoteller/templates/screenshots/hoteller_6.png',
				'date'      		=> date( get_option( 'date_format' ), 1531297160 ),
				'type'				=> 'page',
				'subtype'			=> 'page',
				'author'            => 'ThemeGoods',
				'categories'        => array(),
				'keywords'          => array('our menus'),
				'is_pro'            => false,
				'has_page_settings' => false,
				'url'               => 'https://themes.themegoods.com/hoteller/luxury/our-menus/',
			),
			7 	=> array(
				'template_id'      	=> $this->template_prefix .'7',
				'source'            => $this->get_id(),
				'title'             => 'Blog 1',
				'thumbnail'         => 'http://assets.themegoods.com/demo/hoteller/templates/screenshots/hoteller_7.png',
				'date'      		=> date( get_option( 'date_format' ), 1531297160 ),
				'type'				=> 'page',
				'subtype'			=> 'page',
				'author'            => 'ThemeGoods',
				'categories'        => array(),
				'keywords'          => array('blog'),
				'is_pro'            => false,
				'has_page_settings' => false,
				'url'               => 'https://themes.themegoods.com/hoteller/luxury/blog/',
			),
			8 	=> array(
				'template_id'      	=> $this->template_prefix .'8',
				'source'            => $this->get_id(),
				'title'             => 'Explore',
				'thumbnail'         => 'http://assets.themegoods.com/demo/hoteller/templates/screenshots/hoteller_8.png',
				'date'      		=> date( get_option( 'date_format' ), 1531297160 ),
				'type'				=> 'page',
				'subtype'			=> 'page',
				'author'            => 'ThemeGoods',
				'categories'        => array(),
				'keywords'          => array('explore'),
				'is_pro'            => false,
				'has_page_settings' => false,
				'url'               => 'https://themes.themegoods.com/hoteller/luxury/explore/',
			),
			9 	=> array(
				'template_id'      	=> $this->template_prefix .'9',
				'source'            => $this->get_id(),
				'title'             => 'Terms & Conditions',
				'thumbnail'         => 'http://assets.themegoods.com/demo/hoteller/templates/screenshots/hoteller_9.png',
				'date'      		=> date( get_option( 'date_format' ), 1531297160 ),
				'type'				=> 'page',
				'subtype'			=> 'page',
				'author'            => 'ThemeGoods',
				'categories'        => array(),
				'keywords'          => array('terms', 'conditions'),
				'is_pro'            => false,
				'has_page_settings' => false,
				'url'               => 'https://themes.themegoods.com/hoteller/luxury/terms-and-conditions/',
			),
			10 	=> array(
				'template_id'      	=> $this->template_prefix .'10',
				'source'            => $this->get_id(),
				'title'             => 'Gallery',
				'thumbnail'         => 'http://assets.themegoods.com/demo/hoteller/templates/screenshots/hoteller_10.png',
				'date'      		=> date( get_option( 'date_format' ), 1531297160 ),
				'type'				=> 'page',
				'subtype'			=> 'page',
				'author'            => 'ThemeGoods',
				'categories'        => array(),
				'keywords'          => array('gallery'),
				'is_pro'            => false,
				'has_page_settings' => false,
				'url'               => 'https://themes.themegoods.com/hoteller/luxury/gallery/',
			),
			11 	=> array(
				'template_id'      	=> $this->template_prefix .'11',
				'source'            => $this->get_id(),
				'title'             => 'Home 1',
				'thumbnail'         => 'http://assets.themegoods.com/demo/hoteller/templates/screenshots/hoteller_11.png',
				'date'      		=> date( get_option( 'date_format' ), 1531297160 ),
				'type'				=> 'page',
				'subtype'			=> 'page',
				'author'            => 'ThemeGoods',
				'categories'        => array(),
				'keywords'          => array('home'),
				'is_pro'            => false,
				'has_page_settings' => false,
				'url'               => 'https://themes.themegoods.com/hoteller/luxury/',
			),
			12 	=> array(
				'template_id'      	=> $this->template_prefix .'12',
				'source'            => $this->get_id(),
				'title'             => 'Our Rooms 2',
				'thumbnail'         => 'http://assets.themegoods.com/demo/hoteller/templates/screenshots/hoteller_12.png',
				'date'      		=> date( get_option( 'date_format' ), 1531297160 ),
				'type'				=> 'page',
				'subtype'			=> 'page',
				'author'            => 'ThemeGoods',
				'categories'        => array(),
				'keywords'          => array('our rooms'),
				'is_pro'            => false,
				'has_page_settings' => false,
				'url'               => 'https://themes.themegoods.com/hoteller/city/our-rooms/',
			),
			13 	=> array(
				'template_id'      	=> $this->template_prefix .'13',
				'source'            => $this->get_id(),
				'title'             => 'About Us 2',
				'thumbnail'         => 'http://assets.themegoods.com/demo/hoteller/templates/screenshots/hoteller_13.png',
				'date'      		=> date( get_option( 'date_format' ), 1531297160 ),
				'type'				=> 'page',
				'subtype'			=> 'page',
				'author'            => 'ThemeGoods',
				'categories'        => array(),
				'keywords'          => array('about'),
				'is_pro'            => false,
				'has_page_settings' => false,
				'url'               => 'https://themes.themegoods.com/hoteller/city/about-us/',
			),
			14 	=> array(
				'template_id'      	=> $this->template_prefix .'14',
				'source'            => $this->get_id(),
				'title'             => 'Blog 2',
				'thumbnail'         => 'http://assets.themegoods.com/demo/hoteller/templates/screenshots/hoteller_14.png',
				'date'      		=> date( get_option( 'date_format' ), 1531297160 ),
				'type'				=> 'page',
				'subtype'			=> 'page',
				'author'            => 'ThemeGoods',
				'categories'        => array(),
				'keywords'          => array('blog'),
				'is_pro'            => false,
				'has_page_settings' => false,
				'url'               => 'https://themes.themegoods.com/hoteller/city/blog/',
			),
			15 	=> array(
				'template_id'      	=> $this->template_prefix .'15',
				'source'            => $this->get_id(),
				'title'             => 'Home 2',
				'thumbnail'         => 'http://assets.themegoods.com/demo/hoteller/templates/screenshots/hoteller_15.png',
				'date'      		=> date( get_option( 'date_format' ), 1531297160 ),
				'type'				=> 'page',
				'subtype'			=> 'page',
				'author'            => 'ThemeGoods',
				'categories'        => array(),
				'keywords'          => array('home'),
				'is_pro'            => false,
				'has_page_settings' => false,
				'url'               => 'https://themes.themegoods.com/hoteller/city/',
			),
			16 	=> array(
				'template_id'      	=> $this->template_prefix .'16',
				'source'            => $this->get_id(),
				'title'             => 'Our Rooms',
				'thumbnail'         => 'http://assets.themegoods.com/demo/hoteller/templates/screenshots/hoteller_16.png',
				'date'      		=> date( get_option( 'date_format' ), 1531297160 ),
				'type'				=> 'page',
				'subtype'			=> 'page',
				'author'            => 'ThemeGoods',
				'categories'        => array(),
				'keywords'          => array('our rooms'),
				'is_pro'            => false,
				'has_page_settings' => false,
				'url'               => 'https://themes.themegoods.com/hoteller/mountain/our-rooms/',
			),
			17 	=> array(
				'template_id'      	=> $this->template_prefix .'17',
				'source'            => $this->get_id(),
				'title'             => 'About Us 3',
				'thumbnail'         => 'http://assets.themegoods.com/demo/hoteller/templates/screenshots/hoteller_17.png',
				'date'      		=> date( get_option( 'date_format' ), 1531297160 ),
				'type'				=> 'page',
				'subtype'			=> 'page',
				'author'            => 'ThemeGoods',
				'categories'        => array(),
				'keywords'          => array('about'),
				'is_pro'            => false,
				'has_page_settings' => false,
				'url'               => 'https://themes.themegoods.com/hoteller/mountain/about-us/',
			),
			18 	=> array(
				'template_id'      	=> $this->template_prefix .'18',
				'source'            => $this->get_id(),
				'title'             => 'Blog 3',
				'thumbnail'         => 'http://assets.themegoods.com/demo/hoteller/templates/screenshots/hoteller_18.png',
				'date'      		=> date( get_option( 'date_format' ), 1531297160 ),
				'type'				=> 'page',
				'subtype'			=> 'page',
				'author'            => 'ThemeGoods',
				'categories'        => array(),
				'keywords'          => array('blog'),
				'is_pro'            => false,
				'has_page_settings' => false,
				'url'               => 'https://themes.themegoods.com/hoteller/mountain/blog/',
			),
			19 	=> array(
				'template_id'      	=> $this->template_prefix .'19',
				'source'            => $this->get_id(),
				'title'             => 'Our Rooms 4',
				'thumbnail'         => 'http://assets.themegoods.com/demo/hoteller/templates/screenshots/hoteller_19.png',
				'date'      		=> date( get_option( 'date_format' ), 1531297160 ),
				'type'				=> 'page',
				'subtype'			=> 'page',
				'author'            => 'ThemeGoods',
				'categories'        => array(),
				'keywords'          => array('our rooms'),
				'is_pro'            => false,
				'has_page_settings' => false,
				'url'               => 'https://themes.themegoods.com/hoteller/beach/our-rooms/',
			),
			20 	=> array(
				'template_id'      	=> $this->template_prefix .'20',
				'source'            => $this->get_id(),
				'title'             => 'About Us 4',
				'thumbnail'         => 'http://assets.themegoods.com/demo/hoteller/templates/screenshots/hoteller_20.png',
				'date'      		=> date( get_option( 'date_format' ), 1531297160 ),
				'type'				=> 'page',
				'subtype'			=> 'page',
				'author'            => 'ThemeGoods',
				'categories'        => array(),
				'keywords'          => array('about'),
				'is_pro'            => false,
				'has_page_settings' => false,
				'url'               => 'https://themes.themegoods.com/hoteller/beach/about-us/',
			),
			21 	=> array(
				'template_id'      	=> $this->template_prefix .'21',
				'source'            => $this->get_id(),
				'title'             => 'Blog 4',
				'thumbnail'         => 'http://assets.themegoods.com/demo/hoteller/templates/screenshots/hoteller_21.png',
				'date'      		=> date( get_option( 'date_format' ), 1531297160 ),
				'type'				=> 'page',
				'subtype'			=> 'page',
				'author'            => 'ThemeGoods',
				'categories'        => array(),
				'keywords'          => array('blog'),
				'is_pro'            => false,
				'has_page_settings' => false,
				'url'               => 'https://themes.themegoods.com/hoteller/beach/blog/',
			),
			22 	=> array(
				'template_id'      	=> $this->template_prefix .'22',
				'source'            => $this->get_id(),
				'title'             => 'Home 4',
				'thumbnail'         => 'http://assets.themegoods.com/demo/hoteller/templates/screenshots/hoteller_22.png',
				'date'      		=> date( get_option( 'date_format' ), 1531297160 ),
				'type'				=> 'page',
				'subtype'			=> 'page',
				'author'            => 'ThemeGoods',
				'categories'        => array(),
				'keywords'          => array('home'),
				'is_pro'            => false,
				'has_page_settings' => false,
				'url'               => 'https://themes.themegoods.com/hoteller/beach/',
			),
			23 	=> array(
				'template_id'      	=> $this->template_prefix .'23',
				'source'            => $this->get_id(),
				'title'             => 'Our Rooms 5',
				'thumbnail'         => 'http://assets.themegoods.com/demo/hoteller/templates/screenshots/hoteller_23.png',
				'date'      		=> date( get_option( 'date_format' ), 1531297160 ),
				'type'				=> 'page',
				'subtype'			=> 'page',
				'author'            => 'ThemeGoods',
				'categories'        => array(),
				'keywords'          => array('our rooms'),
				'is_pro'            => false,
				'has_page_settings' => false,
				'url'               => 'https://themes.themegoods.com/hoteller/apartment/our-rooms/',
			),
			24 	=> array(
				'template_id'      	=> $this->template_prefix .'24',
				'source'            => $this->get_id(),
				'title'             => 'About Us 5',
				'thumbnail'         => 'http://assets.themegoods.com/demo/hoteller/templates/screenshots/hoteller_24.png',
				'date'      		=> date( get_option( 'date_format' ), 1531297160 ),
				'type'				=> 'page',
				'subtype'			=> 'page',
				'author'            => 'ThemeGoods',
				'categories'        => array(),
				'keywords'          => array('about'),
				'is_pro'            => false,
				'has_page_settings' => false,
				'url'               => 'https://themes.themegoods.com/hoteller/apartment/about-us/',
			),
			25 	=> array(
				'template_id'      	=> $this->template_prefix .'25',
				'source'            => $this->get_id(),
				'title'             => 'Blog 5',
				'thumbnail'         => 'http://assets.themegoods.com/demo/hoteller/templates/screenshots/hoteller_25.png',
				'date'      		=> date( get_option( 'date_format' ), 1531297160 ),
				'type'				=> 'page',
				'subtype'			=> 'page',
				'author'            => 'ThemeGoods',
				'categories'        => array(),
				'keywords'          => array('blog'),
				'is_pro'            => false,
				'has_page_settings' => false,
				'url'               => 'https://themes.themegoods.com/hoteller/apartment/blog/',
			),
			26 	=> array(
				'template_id'      	=> $this->template_prefix .'26',
				'source'            => $this->get_id(),
				'title'             => 'Home 5',
				'thumbnail'         => 'http://assets.themegoods.com/demo/hoteller/templates/screenshots/hoteller_26.png',
				'date'      		=> date( get_option( 'date_format' ), 1531297160 ),
				'type'				=> 'page',
				'subtype'			=> 'page',
				'author'            => 'ThemeGoods',
				'categories'        => array(),
				'keywords'          => array('home'),
				'is_pro'            => false,
				'has_page_settings' => false,
				'url'               => 'https://themes.themegoods.com/hoteller/apartment/',
			),
			27 	=> array(
				'template_id'      	=> $this->template_prefix .'27',
				'source'            => $this->get_id(),
				'title'             => 'Home 6',
				'thumbnail'         => 'http://assets.themegoods.com/demo/hoteller/templates/screenshots/hoteller_27.png',
				'date'      		=> date( get_option( 'date_format' ), 1539340117 ),
				'type'				=> 'page',
				'subtype'			=> 'page',
				'author'            => 'ThemeGoods',
				'categories'        => array(),
				'keywords'          => array('home'),
				'is_pro'            => false,
				'has_page_settings' => false,
				'url'               => 'https://themes.themegoods.com/hoteller/cultural/',
			),
			28 	=> array(
				'template_id'      	=> $this->template_prefix .'28',
				'source'            => $this->get_id(),
				'title'             => 'Our Rooms 6',
				'thumbnail'         => 'http://assets.themegoods.com/demo/hoteller/templates/screenshots/hoteller_28.png',
				'date'      		=> date( get_option( 'date_format' ), 1531297160 ),
				'type'				=> 'page',
				'subtype'			=> 'page',
				'author'            => 'ThemeGoods',
				'categories'        => array(),
				'keywords'          => array('our rooms'),
				'is_pro'            => false,
				'has_page_settings' => false,
				'url'               => 'https://themes.themegoods.com/hoteller/cultural/our-rooms/',
			),
			29 	=> array(
				'template_id'      	=> $this->template_prefix .'29',
				'source'            => $this->get_id(),
				'title'             => 'Dining 6',
				'thumbnail'         => 'http://assets.themegoods.com/demo/hoteller/templates/screenshots/hoteller_29.png',
				'date'      		=> date( get_option( 'date_format' ), 1531297160 ),
				'type'				=> 'page',
				'subtype'			=> 'page',
				'author'            => 'ThemeGoods',
				'categories'        => array(),
				'keywords'          => array('dining'),
				'is_pro'            => false,
				'has_page_settings' => false,
				'url'               => 'https://themes.themegoods.com/hoteller/cultural/dining/',
			),
			30 	=> array(
				'template_id'      	=> $this->template_prefix .'30',
				'source'            => $this->get_id(),
				'title'             => 'About Us 6',
				'thumbnail'         => 'http://assets.themegoods.com/demo/hoteller/templates/screenshots/hoteller_30.png',
				'date'      		=> date( get_option( 'date_format' ), 1531297160 ),
				'type'				=> 'page',
				'subtype'			=> 'page',
				'author'            => 'ThemeGoods',
				'categories'        => array(),
				'keywords'          => array('about'),
				'is_pro'            => false,
				'has_page_settings' => false,
				'url'               => 'https://themes.themegoods.com/hoteller/cultural/about-us/',
			),
			31 	=> array(
				'template_id'      	=> $this->template_prefix .'31',
				'source'            => $this->get_id(),
				'title'             => 'Contact 6',
				'thumbnail'         => 'http://assets.themegoods.com/demo/hoteller/templates/screenshots/hoteller_31.png',
				'date'      		=> date( get_option( 'date_format' ), 1531297160 ),
				'type'				=> 'page',
				'subtype'			=> 'page',
				'author'            => 'ThemeGoods',
				'categories'        => array(),
				'keywords'          => array('contact'),
				'is_pro'            => false,
				'has_page_settings' => false,
				'url'               => 'https://themes.themegoods.com/hoteller/cultural/contact/',
			),

		);
		
		if ( ! empty( $templates_data ) ) {
			foreach ( $templates_data as $template_data ) {
				$templates[] = $this->get_item( $template_data );
			}
		}

		if ( ! empty( $args ) ) {
			$templates = wp_list_filter( $templates, $args );
		}
		
		return $templates;
	}
	
	public function get_item( $template_data ) {
		return array(
			'template_id'     => $template_data['template_id'],
			'source'          => 'remote',
			'type'            => $template_data['type'],
			'subtype'         => $template_data['subtype'],
			'title'           => $template_data['title'],
			'thumbnail'       => $template_data['thumbnail'],
			'date'            => $template_data['date'],
			'author'          => $template_data['author'],
			'tags'            => $template_data['tags'],
			'isPro'           => ( 1 == $template_data['isPro'] ),
			'popularityIndex' => (int) $template_data['popularityIndex'],
			'trendIndex'      => (int) $template_data['trendIndex'],
			'hasPageSettings' => ( 1 == $template_data['hasPageSettings'] ),
			'url'             => $template_data['url'],
			'favorite'        => ( 1 == $template_data['favorite'] ),
		);
	}

	public function save_item( $template_data ) {
		return false;
	}

	public function update_item( $new_data ) {
		return false;
	}

	public function delete_template( $template_id ) {
		return false;
	}

	public function export_template( $template_id ) {
		return false;
	}

	public function get_data( array $args, $context = 'display' ) {
		$url	  = 'http://assets.themegoods.com/demo/hoteller/templates/json/'.$args['template_id'].'.json';
		$response = wp_remote_get( $url, array( 'timeout' => 60 ) );
		$body     = wp_remote_retrieve_body( $response );
		$body     = json_decode( $body, true );
		$data     = ! empty( $body['content'] ) ? $body['content'] : false;
		
		$result = array();

		$result['content']       = $this->replace_elements_ids($data);
		$result['content']       = $this->process_export_import_content( $result['content'], 'on_import' );
		$result['page_settings'] = array();

		return $result;
	}
}
